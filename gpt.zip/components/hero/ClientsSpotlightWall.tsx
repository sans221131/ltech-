"use client";

import { useEffect, useMemo, useRef, useState } from "react";

const CLIENTS: Client[] = [
  { name: "Acme Bank",   logoSrc: "/logos/acme-bank.svg",   href: "#" },
  { name: "Nimbus Air",  logoSrc: "/logos/nimbus-air.svg",  href: "#" },
  { name: "Kairo Labs",  logoSrc: "/logos/kairo-labs.svg",  href: "#" },
  { name: "Orbit Hotels",logoSrc: "/logos/orbit-hotels.svg",href: "#" },
  { name: "Delta Grid",  logoSrc: "/logos/delta-grid.svg",  href: "#" },
  { name: "Pavilion",    logoSrc: "/logos/pavilion.svg",    href: "#" },
  // add more as needed; grid auto-wraps
];

// ── Types ──────────────────────────────────────────────────────────────────────
export type Client = {
  name: string;
  logoSrc: string;  // prefer single-color SVG/PNG with transparency
  href?: string;
  alt?: string;
};

type Props = {
  items: Client[];
  className?: string;
  backgroundHex?: string; // page bg for seamless blend
  panelHeight?: number;   // px visual height
  columns?: number;       // logo grid columns in atlas
  cellSize?: number;      // px per logo cell in atlas (hi-DPI internal)
};

// ── Utility: clamp DPR ─────────────────────────────────────────────────────────
function getCappedDPR(max = 1.5) {
  if (typeof window === "undefined") return 1;
  return Math.min(window.devicePixelRatio || 1, max);
}

// ── Utility: create logo atlas (offscreen canvas) ──────────────────────────────
async function buildAtlas(
  clients: Client[],
  opts: { columns: number; cell: number }
): Promise<{ canvas: HTMLCanvasElement; rows: number }> {
  const { columns, cell } = opts;
  const rows = Math.ceil(clients.length / columns);

  const atlas = document.createElement("canvas");
  atlas.width = columns * cell;
  atlas.height = rows * cell;
  const ctx = atlas.getContext("2d");
  if (!ctx) throw new Error("2D context unavailable");

  // clear to transparent
  ctx.clearRect(0, 0, atlas.width, atlas.height);

  // load all images
  const imgs = await Promise.all(
    clients.map(
      (c) =>
        new Promise<HTMLImageElement>((resolve, reject) => {
          const img = new Image();
          img.crossOrigin = "anonymous";
          img.onload = () => resolve(img);
          img.onerror = reject;
          img.src = c.logoSrc;
        })
    )
  );

  // draw padded, centered, monochrome
  const pad = Math.floor(cell * 0.18);
  for (let i = 0; i < imgs.length; i++) {
    const col = i % columns;
    const row = Math.floor(i / columns);
    const x = col * cell;
    const y = row * cell;
    const boxW = cell - pad * 2;
    const boxH = cell - pad * 2;

    const img = imgs[i];
    const r = img.width / img.height;
    let w = boxW, h = Math.floor(boxW / r);
    if (h > boxH) { h = boxH; w = Math.floor(boxH * r); }

    const ix = x + Math.floor((cell - w) / 2);
    const iy = y + Math.floor((cell - h) / 2);

    // draw the original
    ctx.drawImage(img, ix, iy, w, h);

    // convert to monochrome by multiplying channels (cheap desaturate)
    const id = ctx.getImageData(ix, iy, w, h);
    const d = id.data;
    for (let p = 0; p < d.length; p += 4) {
      const rpx = d[p], gpx = d[p + 1], bpx = d[p + 2];
      // luminance
      const ypx = 0.2126 * rpx + 0.7152 * gpx + 0.0722 * bpx;
      d[p] = d[p + 1] = d[p + 2] = ypx;
      // keep alpha as-is
    }
    ctx.putImageData(id, ix, iy);
  }

  return { canvas: atlas, rows };
}

// ── Shaders (tiny) ────────────────────────────────────────────────────────────
const VERT = `
precision mediump float;
attribute vec2 position;
attribute vec2 uv;
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

// The fragment fakes a frosted/refraction vibe by:
// 1) Sampling the logo atlas as an "etch" mask
// 2) Creating a pseudo normal field affected by mouse/time
// 3) Using that to modulate light, micro-specular and a tiny UV offset
const FRAG = `
precision mediump float;
varying vec2 vUv;
uniform sampler2D uAtlas;
uniform vec2 uPanelUV;      // atlas scaling to fit plane
uniform vec2 uMouse;        // normalized [-1,1]
uniform float uTime;
uniform float uInk;         // 0..1 "ink near cursor"
uniform vec3 uInkColor;
uniform vec3 uBg;
uniform float uRefraction;  // 0..1
uniform float uDeboss;      // strength

// simple hash noise
float hash(vec2 p){ p = fract(p*0.3183099+vec2(0.1,0.7)); return fract(23.3*dot(p, p+0.23)); }

// pseudo normal from cheap noise / ripples
vec3 pseudoNormal(vec2 uv) {
  float t = uTime * 0.15;
  float n1 = sin( (uv.x*6.283 + t*2.0) ) * 0.5 + 0.5;
  float n2 = cos( (uv.y*6.283 - t*1.6) ) * 0.5 + 0.5;
  vec2 g = vec2(n1 - 0.5, n2 - 0.5);
  // mouse tilts the panel
  g += uMouse * 0.15;
  vec3 N = normalize(vec3(g.x, g.y, 1.0));
  return N;
}

void main() {
  // Fit atlas into panel UV space
  vec2 atlasUV = vUv * uPanelUV;

  // Fetch atlas gray value (logos drawn in luminance)
  vec3 atlas = texture2D(uAtlas, atlasUV).rgb;
  float logo = clamp(1.0 - atlas.r, 0.0, 1.0); // invert to treat logos as "carved"

  // normals & lighting
  vec3 N = pseudoNormal(vUv);
  vec3 L = normalize(vec3(0.4, 0.7, 0.6));
  // swing the light slightly over time
  float s = sin(uTime*0.4)*0.2;
  L.xy += vec2(s, -s*0.5);
  L = normalize(L);

  float diff = max(dot(N, L), 0.0);
  float rim = pow(1.0 - max(dot(N, vec3(0.0,0.0,1.0)), 0.0), 2.0);

  // tiny "refraction" by offsetting atlas sample with normal
  vec2 refrUV = atlasUV + N.xy * 0.01 * uRefraction;
  float logoRefr = clamp(1.0 - texture2D(uAtlas, refrUV).r, 0.0, 1.0);

  // base plate color (frosted)
  vec3 base = mix(uBg, uBg*0.92, diff*0.4 + rim*0.12);

  // deboss shading: darken inside the carved logo using lighting
  float carve = logoRefr;
  float shade = smoothstep(0.0, 1.0, carve) * (0.35 + diff*0.25) * uDeboss;
  vec3 debossed = base - vec3(shade);

  // "ink" reveal near cursor: simple radial based on mouse direction -> uv
  float mx = (uMouse.x*0.5+0.5);
  float my = (uMouse.y*0.5+0.5);
  float d = distance(vUv, vec2(mx, my));
  float inkArea = smoothstep(0.32, 0.0, d) * uInk; // localized
  vec3 inkCol = mix(debossed, uInkColor, inkArea * carve);

  // assemble: outside logos = debossed plate; inside logos = debossed + optional ink
  vec3 col = mix(debossed, inkCol, carve);

  gl_FragColor = vec4(col, 1.0);
}
`;

// ── Main Component ────────────────────────────────────────────────────────────
export default function ClientsHoloPanel({
  items,
  className = "",
  backgroundHex = "#F8F7F3",
  panelHeight = 220,
  columns = 6,
  cellSize = 256, // internal atlas res per cell
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [reducedMotion, setReducedMotion] = useState(false);
  const [webglAvailable, setWebglAvailable] = useState(true);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReducedMotion(mq.matches);
    apply();
    mq.addEventListener?.("change", apply);
    return () => mq.removeEventListener?.("change", apply);
  }, []);

  const bgRgb = useMemo(() => hexToRgb(backgroundHex) ?? { r: 248, g: 247, b: 243 }, [backgroundHex]);

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;
    if (reducedMotion) return; // fallback will render

    let gl: WebGLRenderingContext | null = null;
    try {
      gl = canvasRef.current.getContext("webgl", { antialias: true, alpha: false }) as WebGLRenderingContext | null;
      if (!gl) throw new Error("no webgl");
    } catch {
      setWebglAvailable(false);
      return;
    }

    let raf = 0;
    let running = true;
    const DPR = getCappedDPR(1.5);

  // lazy import only in client
  let program: WebGLProgram | null = null;
  let aPos = -1, aUV = -1;
  let uAtlas: WebGLUniformLocation | null = null;
  let uPanelUV: WebGLUniformLocation | null = null;
  let uMouse: WebGLUniformLocation | null = null;
  let uTime: WebGLUniformLocation | null = null;
  let uInk: WebGLUniformLocation | null = null;
  let uInkColor: WebGLUniformLocation | null = null;
  let uBg: WebGLUniformLocation | null = null;
  let uRefraction: WebGLUniformLocation | null = null;
  let uDeboss: WebGLUniformLocation | null = null;
  let texAtlas: WebGLTexture | null = null;

    const quad = new Float32Array([
      // x, y, u, v
      -1, -1, 0, 0,
       1, -1, 1, 0,
      -1,  1, 0, 1,
       1,  1, 1, 1,
    ]);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, quad, gl.STATIC_DRAW);

    function compileShader(type: number, src: string) {
      const sh = gl!.createShader(type)!;
      gl!.shaderSource(sh, src);
      gl!.compileShader(sh);
      if (!gl!.getShaderParameter(sh, gl!.COMPILE_STATUS)) {
        const info = gl!.getShaderInfoLog(sh);
        throw new Error("Shader compile failed: " + info);
      }
      return sh;
    }

    function linkProgram(vs: WebGLShader, fs: WebGLShader) {
      const p = gl!.createProgram()!;
      gl!.attachShader(p, vs);
      gl!.attachShader(p, fs);
      gl!.bindAttribLocation(p, 0, "position");
      gl!.bindAttribLocation(p, 1, "uv");
      gl!.linkProgram(p);
      if (!gl!.getProgramParameter(p, gl!.LINK_STATUS)) {
        throw new Error("Program link failed: " + gl!.getProgramInfoLog(p));
      }
      return p;
    }

    async function init() {
      // Build atlas
      const { canvas: atlasCanvas, rows } = await buildAtlas(items, { columns, cell: cellSize });

      // GL init
      const vs = compileShader(gl!.VERTEX_SHADER, VERT);
      const fs = compileShader(gl!.FRAGMENT_SHADER, FRAG);
      program = linkProgram(vs, fs);
      gl!.useProgram(program);

      aPos = gl!.getAttribLocation(program!, "position");
      aUV = gl!.getAttribLocation(program!, "uv");

      uAtlas = gl!.getUniformLocation(program!, "uAtlas");
      uPanelUV = gl!.getUniformLocation(program!, "uPanelUV");
      uMouse = gl!.getUniformLocation(program!, "uMouse");
      uTime = gl!.getUniformLocation(program!, "uTime");
      uInk = gl!.getUniformLocation(program!, "uInk");
      uInkColor = gl!.getUniformLocation(program!, "uInkColor");
      uBg = gl!.getUniformLocation(program!, "uBg");
      uRefraction = gl!.getUniformLocation(program!, "uRefraction");
      uDeboss = gl!.getUniformLocation(program!, "uDeboss");

      // Upload atlas as texture
      texAtlas = gl!.createTexture();
      gl!.activeTexture(gl!.TEXTURE0);
      gl!.bindTexture(gl!.TEXTURE_2D, texAtlas);
      // avoid power-of-two constraints by using clamp+linear
      gl!.texParameteri(gl!.TEXTURE_2D, gl!.TEXTURE_WRAP_S, gl!.CLAMP_TO_EDGE);
      gl!.texParameteri(gl!.TEXTURE_2D, gl!.TEXTURE_WRAP_T, gl!.CLAMP_TO_EDGE);
      gl!.texParameteri(gl!.TEXTURE_2D, gl!.TEXTURE_MIN_FILTER, gl!.LINEAR);
      gl!.texParameteri(gl!.TEXTURE_2D, gl!.TEXTURE_MAG_FILTER, gl!.LINEAR);
      gl!.pixelStorei(gl!.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl!.texImage2D(gl!.TEXTURE_2D, 0, gl!.RGBA, gl!.RGBA, gl!.UNSIGNED_BYTE, atlasCanvas);

      // geometry layout
      gl!.bindBuffer(gl!.ARRAY_BUFFER, vbo);
      gl!.enableVertexAttribArray(aPos);
      gl!.vertexAttribPointer(aPos, 2, gl!.FLOAT, false, 16, 0);
      gl!.enableVertexAttribArray(aUV);
      gl!.vertexAttribPointer(aUV, 2, gl!.FLOAT, false, 16, 8);

      // uniforms static
      gl!.uniform1i(uAtlas, 0);
      gl!.uniform3f(uBg, bgRgb.r / 255, bgRgb.g / 255, bgRgb.b / 255);
      gl!.uniform3f(uInkColor, 16/255, 16/255, 16/255); // #101010
      gl!.uniform1f(uRefraction, 0.65);
      gl!.uniform1f(uDeboss, 1.0);

      // panel UV fit: ensure texture aspect fits plane (we just letterbox vertically)
      const panelUVx = 1.0;
      const panelUVy = (rows * 1.0 * cellSize) / (columns * 1.0 * cellSize);
      gl!.uniform2f(uPanelUV, panelUVx, panelUVy);

      resize();
      loop(0);
    }

    function resize() {
      if (!containerRef.current || !canvasRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const w = Math.max(320, rect.width);
      const h = panelHeight;

      canvasRef.current.width = Math.floor(w * DPR);
      canvasRef.current.height = Math.floor(h * DPR);
      canvasRef.current.style.width = `${w}px`;
      canvasRef.current.style.height = `${h}px`;

      gl!.viewport(0, 0, canvasRef.current.width, canvasRef.current.height);
      // clear to background
      gl!.clearColor(bgRgb.r / 255, bgRgb.g / 255, bgRgb.b / 255, 1);
    }

    let t0 = performance.now();
    let mouse = { x: 0, y: 0 };
    let ink = 0;

    function loop(now: number) {
      if (!running) return;
      raf = requestAnimationFrame(loop);
      const dt = (now - t0) / 1000;
      t0 = now;

      // ease ink down
      ink += ((0 as number) - ink) * Math.min(1, dt * 0.8);

      gl!.clear(gl!.COLOR_BUFFER_BIT);
      gl!.useProgram(program!);
      gl!.uniform1f(uTime, now / 1000);
      gl!.uniform2f(uMouse, mouse.x, mouse.y);
      gl!.uniform1f(uInk, ink);
      gl!.drawArrays(gl!.TRIANGLE_STRIP, 0, 4);
    }

    function onPointerMove(ev: PointerEvent) {
      if (!canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      const nx = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = ((ev.clientY - rect.top) / rect.height) * 2 - 1;
      mouse.x += (nx - mouse.x) * 0.2;
      mouse.y += (1 - ny - mouse.y - 1) * 0.2; // invert y to 0..1 then to -1..1
    }

    function onPointerEnter() {
      // quick ink pulse
      ink = 1;
    }

    const ro = new ResizeObserver(resize);
    ro.observe(containerRef.current);

    canvasRef.current.addEventListener("pointermove", onPointerMove);
    canvasRef.current.addEventListener("pointerenter", onPointerEnter);

    init().catch(() => {
      setWebglAvailable(false);
    });

    // page/tab visibility perf guard
    const vis = () => { running = !document.hidden; if (running) { t0 = performance.now(); raf = requestAnimationFrame(loop); } };
    document.addEventListener("visibilitychange", vis);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      document.removeEventListener("visibilitychange", vis);
      ro.disconnect();
      canvasRef.current?.removeEventListener("pointermove", onPointerMove);
      canvasRef.current?.removeEventListener("pointerenter", onPointerEnter);
      if (gl) {
        gl.getExtension("WEBGL_lose_context")?.loseContext?.();
      }
    };
  }, [items, reducedMotion, bgRgb, columns, cellSize, panelHeight]);

  // Fallback if reduced motion or no WebGL
  if (reducedMotion || !webglAvailable) {
    return (
      <section
        aria-label="Clients who trust us"
        className={`mx-auto max-w-7xl px-6 md:px-10 lg:px-16 w-full ${className ?? ""}`}
      >
        <div className="mb-3">
          <span className="inline-flex items-center gap-2 rounded-full border border-black/10 bg-white/60 px-3 py-1 text-xs text-neutral-700 backdrop-blur-sm">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-neutral-900" />
            Trusted by teams at
          </span>
        </div>

        <div
          className="rounded-3xl border border-black/10 bg-white/60 backdrop-blur-sm p-6 md:p-8"
          style={{ boxShadow: "inset 0 1px 0 rgba(255,255,255,0.8), inset 0 -1px 0 rgba(0,0,0,0.04)" }}
        >
          <div className="grid grid-cols-3 md:grid-cols-6 gap-6 items-center">
            {items.map((c) => (
              c.href ? (
                <a key={c.name} href={c.href} aria-label={c.name} className="justify-self-center">
                  <img
                    src={c.logoSrc}
                    alt={c.alt ?? c.name}
                    className="h-7 md:h-8 w-auto object-contain select-none grayscale contrast-75 opacity-80"
                    loading="lazy"
                  />
                </a>
              ) : (
                <img
                  key={c.name}
                  src={c.logoSrc}
                  alt={c.alt ?? c.name}
                  className="h-7 md:h-8 w-auto object-contain justify-self-center select-none grayscale contrast-75 opacity-80"
                  loading="lazy"
                />
              )
            ))}
          </div>
        </div>
      </section>
    );
  }

  // WebGL panel
  return (
    <section
      aria-label="Clients who trust us"
      className={`mx-auto max-w-7xl px-6 md:px-10 lg:px-16 w-full ${className ?? ""}`}
    >
      <div className="mb-3">
        <span className="inline-flex items-center gap-2 rounded-full border border-black/10 bg-white/60 px-3 py-1 text-xs text-neutral-700 backdrop-blur-sm">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-neutral-900" />
          Trusted by teams at
        </span>
      </div>

      <div
        ref={containerRef}
        className="relative overflow-hidden rounded-3xl border border-black/10 bg-white/40 backdrop-blur-sm"
        style={{
          height: panelHeight,
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.7), inset 0 -1px 0 rgba(0,0,0,0.05)",
        }}
      >
        <canvas ref={canvasRef} />
      </div>
    </section>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const m = hex.trim().replace("#", "");
  if (m.length === 3) {
    const r = parseInt(m[0] + m[0], 16);
    const g = parseInt(m[1] + m[1], 16);
    const b = parseInt(m[2] + m[2], 16);
    return { r, g, b };
  }
  if (m.length === 6) {
    const r = parseInt(m.slice(0, 2), 16);
    const g = parseInt(m.slice(2, 4), 16);
    const b = parseInt(m.slice(4, 6), 16);
    return { r, g, b };
  }
  return null;
}
