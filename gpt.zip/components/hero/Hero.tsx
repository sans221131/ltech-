"use client";

import HeroBoids from "./viz/HeroBoids";
import ClientsRow from "./ClientsSpotlightWall";

type Client = { name: string; logoSrc: string; alt?: string };

type HeroProps = {
  eyebrow?: string;
  headline: string;
  subhead?: string;
  ctaText?: string;
  ctaHref?: string;
  accent?: string;   // particle color
  bg?: string;       // canvas fade color, your page bg
  clients?: Client[];
};

export default function Hero({
  eyebrow = "Architecture-first engineering",
  headline,
  subhead = "Edge-first APIs, resilient data layers, and motion that respects budgets.",
  ctaText = "Explore solutions",
  ctaHref = "/solutions",
  accent = "#101010",
  bg = "#F8F7F3",
  clients = [],
}: HeroProps) {
  return (
    <section
      className="relative isolate w-full bg-[#F8F7F3] text-[#101010] pt-16 md:pt-24"
      aria-labelledby="hero-heading"
    >
      <div className="mx-auto max-w-7xl px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-12 gap-8 items-center">
          {/* Left: text */}
          <div className="col-span-12 md:col-span-7 lg:col-span-6">
            {eyebrow && (
              <div className="text-[12px] tracking-[0.15em] uppercase opacity-70">
                {eyebrow}
              </div>
            )}
            <h1 id="hero-heading" className="mt-3 font-display text-5xl md:text-7xl leading-[1.05]">
              {headline}
            </h1>
            {subhead && (
              <p className="mt-4 text-[16px] md:text-[18px] text-neutral-700 max-w-xl">
                {subhead}
              </p>
            )}
            <div className="mt-6">
              <a
                href={ctaHref}
                className="inline-flex items-center gap-2 rounded-2xl px-4 py-2 border border-neutral-300 hover:border-neutral-900 transition"
              >
                {ctaText}
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
                  <path d="M5 12h14M13 5l7 7-7 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Right: viz (kept responsive, fixed height on desktop) */}
          <div className="col-span-12 md:col-span-5 lg:col-span-6">
            <div className="relative h-[42vh] min-h-[320px] max-h-[520px] md:h-[56vh]">
              <HeroBoids
                variant="flowGlow"
                headline={headline}
                accent={accent}
                bg={bg}
              />
            </div>
          </div>
        </div>
      </div>

      {clients.length > 0 && (
        <div className="mt-8 pb-10">
          <div className="text-center text-sm opacity-70 mb-3">Clients who trust us</div>
          <ClientsRow items={clients} />
        </div>
      )}
    </section>
  );
}
