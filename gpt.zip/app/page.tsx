// /app/page.tsx
import HeroSection from "./sections/hero-section";
import ClientsSpotlightWall, { type Client } from "@/components/hero/ClientsSpotlightWall";
import WhatWeDo from "@/components/sections/WhatWeDo";
import ServicesSection from "@/components/sections/ServicesSection";
import AboutUs from "@/components/sections/AboutUs";
import TeamSection from "@/components/sections/TeamSection";
import SubmitBrief from "@/components/sections/SubmitBrief";
import SiteFooter from "@/components/sections/SiteFooter";

const CLIENTS: Client[] = [
  { name: "Acme Bank",   logoSrc: "/logos/acme-bank.svg",   href: "#" },
  { name: "Nimbus Air",  logoSrc: "/logos/nimbus-air.svg",  href: "#" },
  { name: "Kairo Labs",  logoSrc: "/logos/kairo-labs.svg",  href: "#" },
  { name: "Orbit Hotels",logoSrc: "/logos/orbit-hotels.svg",href: "#" },
  { name: "Delta Grid",  logoSrc: "/logos/delta-grid.svg",  href: "#" },
  { name: "Pavilion",    logoSrc: "/logos/pavilion.svg",    href: "#" },
  // add more as needed; grid auto-wraps
];

export default function HomePage() {
  return (
    <>
      <HeroSection />

      {/* New: Spotlight Deboss Wall (quiet, premium) */}
      <ClientsSpotlightWall
        items={CLIENTS}
        // optional knobs:
        // backgroundHex="#F8F7F3"
        // columnsSm={3}
        // columnsMd={4}
        // columnsLg={6}
      />

      <WhatWeDo />
      <ServicesSection />
      <AboutUs />
      <TeamSection />
      <SubmitBrief />
      <SiteFooter />
    </>
  );
}
